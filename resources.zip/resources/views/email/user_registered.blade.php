<!DOCTYPE html>
<html>
<head>
    <title>New User Registration</title>
</head>
<body>
    <h1>New User Registration</h1>
    <p>A new user has registered using Stripe:</p>
    <p><strong>Name:</strong> {{ $userName }}</p>
    <p><strong>Email:</strong> {{ $userEmail }}</p>
</body>
</html>
