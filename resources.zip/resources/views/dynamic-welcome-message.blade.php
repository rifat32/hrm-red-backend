{!! $html_content !!}
